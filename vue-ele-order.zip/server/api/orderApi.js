const db = require('../config/db')
// import express from 'express';
const express = require('express')
const router = express.Router()
const mysql = require('mysql')
const $orderSql = require('../sqlMap/orderSqlMap')

// 连接数据库
const conn = mysql.createConnection(db)

conn.connect()
const jsonWrite = function(res, ret) {
  if (typeof ret === 'undefined') {
    res.json({
      code: '1',
      msg: '操作失败'
    })
  } else {
    res.json(ret)
  }
}

// 增加用户接口
router.post('/query', (req, res) => {
  const sql = $orderSql.order.query
  const params = req.body
  console.log(params)
  conn.query(sql, function(err, result) {
    if (err) {
      console.log(err)
    }
    if (result) {
      jsonWrite(res, result)
    }
  })
})
// 地址加入数据库
router.post('/addAddress', (req, res) => {
  const sql = $orderSql.order.addOrderDetail
  const params = req.body
  console.log(params)
  conn.query(sql, [params.codePeriod, params.goodsSName, params.orderNo, params.orderState, params.orderTime, params.collectPrice,
    params.address], function(err, result) {
    if (err) {
      console.log(err)
    }
    if (result) {
      console.warn(res, result)
      jsonWrite(res, result)
    }
  })
})
module.exports = router
