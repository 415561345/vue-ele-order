// node 后端服务器

const userApi = require('./api/userApi')
const orderApi = require('./api/orderApi')
const fs = require('fs')
const path = require('path')
const bodyParser = require('body-parser')
const express = require('express')
const app = express()
//
// app.all('*', function(req, res, next) {
//   // 设置允许跨域的域名，*代表允许任意域名跨域
//   res.header('Access-Control-Allow-Origin', '*')
//   // 允许的header类型
//   // res.header('Access-Control-Allow-Headers', 'Content-Type,Access-Token')
//   res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
//   // 跨域允许的请求方式
//   res.header('Access-Control-Allow-Methods', 'PUT,POST,GET,DELETE,OPTIONS')
//   // res.header('Access-control-Allow-Credentials', 'true')
//   // 修改程序信息与版本
//   res.header('X-Powered-By', ' 3.2.1')
//   // 内容类型：如果是post请求必须指定这个属性
//   res.header('Content-Type', 'application/json;charset=utf-8')
//   console.log('app.all', res.header)
//   if (req.method.toLowerCase() === 'options') res.send(200) // 让options尝试请求快速结束
//   else next()
// })
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))

// 后端api路由
app.use('/nodeApi/user', userApi)
app.use('/nodeApi/order', orderApi)

// 监听端口
app.listen(3000)
console.log('express 服务已启动，success listen at port:3000......')
