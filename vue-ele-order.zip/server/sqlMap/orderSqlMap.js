// sql语句
const orderSqlMap = {
  // 用户
  order: {
    query: 'SELECT * FROM order_prize',
    addOrderDetail: 'insert into order_prize(order_prizenum,order_prizename,order_number,order_state,order_time,order_collectprice,order_address) ' +
      'values (?, ?, ?, ?, ?, ?, ?)'
  }
}

module.exports = orderSqlMap
