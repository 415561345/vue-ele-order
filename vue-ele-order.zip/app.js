
const express = require('express') // 引入express模块
const mysql = require('mysql') // 引入mysql模块
const app = express() // 创建express的实例

const connection = mysql.createConnection({ // 创建mysql实例
  host: 'localhost',
  port: '3306',
  user: 'lwd',
  password: '123456',
  // socketPath: '/tmp/mysql.sock',
  database: 'order'
})
connection.connect()
const sql = 'SELECT * FROM order_prize'
let str = ''
connection.query(sql, function(err, result) {
  if (err) {
    console.log('[SELECT ERROR]:', err.message)
  }
  str = JSON.stringify(result)
  console.log('数据库查询结果返回到result中')
  console.log(str) // 数据库查询结果返回到result中
})
app.get('/app', function(req, res) {
  res.send(str) // 服务器响应请求
})
connection.end()
app.listen(3000, function() {
  // 监听3000端口
  console.log('后台服务已启动，Server running at 3000 port')
})
