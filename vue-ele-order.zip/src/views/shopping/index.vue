<template>
  <div class="app-container">
    <div class="filter-container">
      <div>
        <p>登陆：</p>
        <div class="filter-item">
          <el-input v-model="loginText" placeholder="请输入账号----密码">
            <template slot="prepend">账号----密码：</template>
          </el-input>
        </div>
        <el-button v-waves class="filter-item" type="primary" icon="el-icon-user" @click="loginClick(1)">
          登陆
        </el-button>
        <!--        <el-button v-waves class="filter-item" type="primary" icon="el-icon-user" @click="queryPrize">-->
        <!--          查询抽奖-->
        <!--        </el-button>-->
        <!--        <el-button v-waves class="filter-item" type="primary" icon="el-icon-user" @click="queryZJiang">-->
        <!--          查询中奖-->
        <!--        </el-button>-->
        <!--        <el-button v-waves class="filter-item" type="primary" icon="el-icon-user" @click="queryOrderDetail">-->
        <!--          查询订单详细信息-->
        <!--        </el-button>-->
      </div>
      <div>
        <p>地址配置:</p>
        <div>
          <div class="filter-item">
            <el-input v-model="name" placeholder="请输入名字">
              <template slot="prepend">名字：</template>
            </el-input>
          </div>
          <div class="filter-item">
            <el-input v-model="address" placeholder="请输入地址">
              <template slot="prepend">地址：</template>
            </el-input>
          </div>
        </div>
        <div>
          <div class="filter-item">
            <el-input v-model="phone" placeholder="请输入手机号">
              <template slot="prepend">手机号：</template>
            </el-input>
          </div>
          <div class="filter-item">
            <el-input v-model="areaId" placeholder="请输入区域ID">
              <template slot="prepend">区域ID：</template>
            </el-input>
          </div>
          <span>(默认深圳罗湖=1041)</span>
          <el-button v-waves class="filter-item" type="primary" icon="el-icon-shopping-cart-2" @click="queryOrderDetail(1604576)">
            保存配置
          </el-button>
        </div>
        <div class="submitAddress">
          <el-button v-waves style="margin-bottom: 50px;" type="warning" icon="el-icon-sold-out" @click="addUserAddress">
            提交订单地址
          </el-button>
        </div>
      </div>
      中奖纪录：
      <el-input v-model="searchText" placeholder="请输入订单号" style="width: 200px;" class="filter-item" />
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="searchClick">
        {{ $t('table.search') }}
      </el-button>
      <!--      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="handleCreate">-->
      <!--        {{ $t('table.add') }}-->
      <!--      </el-button>-->
      <el-button v-waves :loading="downloadLoading" class="filter-item" type="primary" icon="el-icon-download" @click="handleDownload">
        表格导出
      </el-button>
      <!--      <el-checkbox v-model="showReviewer" class="filter-item" style="margin-left:15px;" @change="tableKey=tableKey+1">-->
      <!--        {{ $t('table.reviewer') }}-->
      <!--      </el-checkbox>-->
    </div>

    <el-table
      ref="elTable"
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      current-row-key
      highlight-current-row
      @sort-change="sortChange"
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        type="selection"
        width="40"
      />
      <el-table-column :label="$t('table.id')" prop="id" sortable="custom" align="center" width="50" :class-name="getSortClass('id')">
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="期数" width="80px" align="center">
        <template slot-scope="{row}">
          <span>{{ row.codePeriod }}</span>
        </template>
      </el-table-column>
      <el-table-column
        :label="$t('table.product')"
        min-width="150px"
        show-overflow-tooltip
        align="center"
      >
        <template slot-scope="{row}">
          <span class="link-type">{{ row.goodsSName }}</span>
          <!--          <span class="link-type" @click="handleUpdate(row)">{{ row.goodsSName }}</span>-->
          <el-tag>{{ row.goodsSName }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column :label="$t('table.orderNum')" width="80px" align="center">
        <template slot-scope="{row}">
          <span>{{ row.orderNo }}</span>
        </template>
      </el-table-column>
      <el-table-column :label="$t('table.orderStatus')" width="140px" align="center">
        <template slot-scope="{row}">
          <span :style="{color:row.orderState == '1'?'red':''}">{{ getValByKey(row.orderState,stateArr) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="收货价格" align="center" width="80">
        <template slot-scope="{row}">
          <el-input v-model="row.collectPrice" class="filter-item" />
        </template>
      </el-table-column>
      <el-table-column
        min-width="150px"
        show-overflow-tooltip
        label="收货地址"
        align="center"
      >
        <template slot-scope="{row}">
          <span>{{ row.address }}</span>
        </template>
      </el-table-column>
      <!--      <el-table-column :label="$t('table.actions')" align="center" width="230" class-name="small-padding fixed-width">-->
      <!--        <template slot-scope="{row,$index}">-->
      <!--          <el-button type="primary" size="mini" @click="handleUpdate(row)">-->
      <!--            {{ $t('table.edit') }}-->
      <!--          </el-button>-->
      <!--          &lt;!&ndash;          <el-button v-if="row.status!='published'" size="mini" type="success" @click="handleModifyStatus(row,'published')">&ndash;&gt;-->
      <!--          &lt;!&ndash;            {{ $t('table.publish') }}&ndash;&gt;-->
      <!--          &lt;!&ndash;          </el-button>&ndash;&gt;-->
      <!--          &lt;!&ndash;          <el-button v-if="row.status!='draft'" size="mini" @click="handleModifyStatus(row,'draft')">&ndash;&gt;-->
      <!--          &lt;!&ndash;            {{ $t('table.draft') }}&ndash;&gt;-->
      <!--          &lt;!&ndash;          </el-button>&ndash;&gt;-->
      <!--          <el-button v-if="row.status!='deleted'" size="mini" type="danger" @click="handleDelete(row,$index)">-->
      <!--            {{ $t('table.delete') }}-->
      <!--          </el-button>-->
      <!--        </template>-->
      <!--      </el-table-column>-->
    </el-table>

    <!--    <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />-->

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="70px" style="width: 400px; margin-left:50px;">
        <el-form-item :label="$t('table.type')" prop="type">
          <el-select v-model="temp.type" class="filter-item" placeholder="Please select">
            <el-option v-for="item in calendarTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('table.date')" prop="timestamp">
          <el-date-picker v-model="temp.timestamp" type="datetime" placeholder="Please pick a date" />
        </el-form-item>
        <el-form-item :label="$t('table.title')" prop="title">
          <el-input v-model="temp.title" />
        </el-form-item>
        <el-form-item :label="$t('table.status')">
          <el-select v-model="temp.status" class="filter-item" placeholder="Please select">
            <el-option v-for="item in statusOptions" :key="item" :label="item" :value="item" />
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('table.importance')">
          <el-rate v-model="temp.importance" :colors="['#99A9BF', '#F7BA2A', '#FF9900']" :max="3" style="margin-top:8px;" />
        </el-form-item>
        <el-form-item :label="$t('table.remark')">
          <el-input v-model="temp.remark" :autosize="{ minRows: 2, maxRows: 4}" type="textarea" placeholder="Please input" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">
          {{ $t('table.cancel') }}
        </el-button>
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">
          {{ $t('table.confirm') }}
        </el-button>
      </div>
    </el-dialog>

    <el-dialog :visible.sync="dialogPvVisible" title="Reading statistics">
      <el-table :data="pvData" border fit highlight-current-row style="width: 100%">
        <el-table-column prop="key" label="Channel" />
        <el-table-column prop="pv" label="Pv" />
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogPvVisible = false">{{ $t('table.confirm') }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { Message } from 'element-ui'
import { addAddressToDb, fetchList, fetchPv, createArticle, updateArticle, accLogin, queryPrize, queryZJiang, queryOrderDetail, addUserAddress, addUserAddress2, delUserAddress } from '@/api/article'
import waves from '@/directive/waves' // waves directive
import { parseTime } from '@/utils'
import Pagination from '@/components/Pagination' // secondary package based on el-pagination
import { getToken, setToken } from '@/utils/auth'
const calendarTypeOptions = [
  { key: 'CN', display_name: 'China' },
  { key: 'US', display_name: 'USA' },
  { key: 'JP', display_name: 'Japan' },
  { key: 'EU', display_name: 'Eurozone' }
]

// arr to obj, such as { CN : "China", US : "USA" }
const calendarTypeKeyValue = calendarTypeOptions.reduce((acc, cur) => {
  acc[cur.key] = cur.display_name
  return acc
}, {})

export default {
  name: 'ComplexTable',
  // components: { Pagination },
  directives: { waves },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'info',
        deleted: 'danger'
      }
      return statusMap[status]
    },
    typeFilter(type) {
      return calendarTypeKeyValue[type]
    }
  },
  data() {
    return {
      multipleSelection: [], // 多选数据
      stateArr: [{ key: '1', value: '待提交收货地址' },
        { key: '2', value: '待发货' },
        { key: '3', value: '待确认收货' },
        { key: '10', value: '已完成' }],
      tableKey: 0,
      searchText: '',
      list: [],
      total: 0,
      listLoading: false,
      listQuery: {
        page: 1,
        limit: 20,
        importance: undefined,
        title: undefined,
        type: undefined,
        sort: '+id'
      },
      loginText: '',
      name: '',
      phone: '',
      areaId: '',
      address: '',
      importanceOptions: [1, 2, 3],
      calendarTypeOptions,
      sortOptions: [{ label: 'ID Ascending', key: '+id' }, { label: 'ID Descending', key: '-id' }],
      statusOptions: ['published', 'draft', 'deleted'],
      showReviewer: false,
      temp: {
        id: undefined,
        importance: 1,
        remark: '',
        timestamp: new Date(),
        title: '',
        type: '',
        status: 'published'
      },
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      dialogPvVisible: false,
      pvData: [],
      rules: {
        type: [{ required: true, message: 'type is required', trigger: 'change' }],
        timestamp: [{ type: 'date', required: true, message: 'timestamp is required', trigger: 'change' }],
        title: [{ required: true, message: 'title is required', trigger: 'blur' }]
      },
      downloadLoading: false
    }
  },
  created() {
    // this.getList()
  },
  methods: {
    // 勾选时事件
    handleSelectionChange(val) {
      this.multipleSelection = val
      console.log('this.multipleSelection', this.multipleSelection)
    },
    addAddressToMysql() {
      this.multipleSelection.forEach(
        row => {
          if (row.orderState == 1) {
            const data = {
              orderState: this.getValByKey(row.orderState, this.stateArr),
              orderNo: row.orderNo,
              orderTime: this.dateFormat('YYYY-mm-dd HH:MM', new Date()),
              codePeriod: row.codePeriod,
              goodsSName: row.goodsSName,
              collectPrice: row.collectPrice,
              address: this.address + '-' + new Date().getDate() + '|[第' + row.codePeriod + '期]'
            }
            addAddressToDb(data).then(response => {
              Message({
                message: '订单' + row.orderNo + '地址已加入到数据库',
                type: 'success',
                duration: 3 * 1000,
                center: true
              })
              console.log('地址加入到数据库', response)
            }
            ).catch(err => console.log(err))
          } else {
            Message({
              message: '只能提交待提交收货地址的订单',
              type: 'error',
              duration: 3 * 1000,
              center: true
            })
          }
        }
      )
    },
    // 时间格式化
    dateFormat(fmt, date) {
      let ret
      const opt = {
        'Y+': date.getFullYear().toString(), // 年
        'm+': (date.getMonth() + 1).toString(), // 月
        'd+': date.getDate().toString(), // 日
        'H+': date.getHours().toString(), // 时
        'M+': date.getMinutes().toString(), // 分
        'S+': date.getSeconds().toString() // 秒
        // 有其他格式化字符需求可以继续添加，必须转化成字符串
      }
      for (const k in opt) {
        ret = new RegExp('(' + k + ')').exec(fmt)
        if (ret) {
          fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, '0')))
        }
      }
      return fmt
    },
    // 码值转换
    getValByKey(key, arr) {
      let returnVal = ''
      if (!arr && arr.length === 0) return
      arr.forEach(
        item => {
          if (item.key == key) returnVal = item.value
        }
      )
      return returnVal
    },
    // 新增用户地址
    async addUserAddress() {
      try {
        if (this.multipleSelection.length === 0) {
          Message({
            message: '请勾选待提交地址的数据',
            type: 'error',
            duration: 3 * 1000,
            center: true
          })
          return
        }
        for (const item of this.list) {
          if (item.orderState && item.orderState == 1) {
          // if (item.orderState && item.orderNo == 717738) {
            const res1 = await addUserAddress({
              areaID: this.areaId,
              userName: this.name,
              mobile: this.phone,
              address: this.address + '-' + item.orderNo
            })
            // 新增用户地址第二步
            await addUserAddress2({
              orderNO: item.orderNo,
              contactID: res1.state,
              auth: getToken() })
            // 最后一步删除地址
            await delUserAddress({
              contactID: res1.state
            })
          }
        }
        this.addAddressToMysql()
      } catch (err) { console.log(err) }
    },
    // 查询抽奖
    queryPrize() {
      queryPrize({ token: getToken() }).then(response => {
        Message({
          message: '请求成功',
          type: 'success',
          duration: 3 * 1000,
          center: true
        })
        console.log('查询抽奖', response)
      }
      ).catch(err => console.log(err))
    },
    // 查询中奖
    queryZJiang() {
      return queryZJiang({
        action: 'getMemberCenterUserRaffleLists',
        region: 0,
        Fidx: 1,
        Eidx: 50, auth: getToken() })
    },
    // 查询订单详情
    queryOrderDetail(orderNo) {
      return queryOrderDetail({ orderNo })
    },
    // 搜索事件
    searchClick() {
      // this.getList().then(response => {
      const searchList = []
      if (this.searchText) {
        this.list.forEach(item => {
          if (item.orderNo == this.searchText) { searchList.push(item) }
        })
        console.log(searchList)
        this.list = searchList
      } else {
        this.loginClick()
      }
      this.total = this.list.length
      // Just to simulate the time of the request
      setTimeout(() => {
        this.listLoading = false
      }, 1.5 * 1000)
      // })
    },
    // 登陆事件
    loginClick(index) {
      if (!this.loginText) {
        return
      }
      const loginArr = this.loginText.split('----')
      // 登陆
      accLogin({
        'account': loginArr[0],
        'password': loginArr[1]
      }).then(response => {
        // 第一次登陆提示
        if (index === 1) {
          Message({
            message: '登陆成功,欢迎' + response.data.userName,
            type: 'success',
            duration: 3 * 1000,
            center: true
          })
        }
        setToken(response.data.token)
        console.log('登陆', response)
        // 查询中奖
        this.setTable()
      }).catch(err => console.log(err))
    },
    // 查询中奖，表格展示
    setTable() {
      this.queryZJiang().then(res => {
        console.log('查询中奖', res)
        const defaultSelectArr = []
        const arr = res.Rows.map((item, index) => {
          item.id = index + 1
          item.collectPrice = '' // 增加收货价格字段
          // 默认勾选待提交收货地址的数据
          if (item.orderState && item.orderState == 1) {
            defaultSelectArr.push(item)
          }
          if (item.orderState && item.orderState > 1) {
            // 查询订单详细信息-收货地址
            this.queryOrderDetail(item.orderNo).then(result => {
              const response2 = result.data
              item.address = response2.receivingInfo.address
              index < 2 && console.log('查询订单详细信息' + item.orderNo + '成功', result)
            }
            )
          }
          return item
        })
        setTimeout(() => {
          this.list = arr
          setTimeout(() => {
            console.log('defaultSelectArr', defaultSelectArr)
            defaultSelectArr.forEach(row => {
              this.$refs.elTable.toggleRowSelection(row)
            })
          }, 0)
        }, 1500)
        this.total = res.Count
      }).catch(err => console.log(err))
    },
    getList() {
      this.listLoading = true
      return fetchList(this.listQuery)
    },
    handleModifyStatus(row, status) {
      this.$message({
        message: '操作成功',
        type: 'success'
      })
      row.status = status
    },
    sortChange(data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    sortByID(order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        importance: 1,
        remark: '',
        timestamp: new Date(),
        title: '',
        status: 'published',
        type: ''
      }
    },
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          this.temp.id = parseInt(Math.random() * 100) + 1024 // mock a id
          this.temp.author = 'vue-element-admin'
          createArticle(this.temp).then(() => {
            this.list.unshift(this.temp)
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '创建成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row) // copy obj
      this.temp.timestamp = new Date(this.temp.timestamp)
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          tempData.timestamp = +new Date(tempData.timestamp) // change Thu Nov 30 2017 16:41:05 GMT+0800 (CST) to 1512031311464
          updateArticle(tempData).then(() => {
            const index = this.list.findIndex(v => v.id === this.temp.id)
            this.list.splice(index, 1, this.temp)
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '更新成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleDelete(row, index) {
      this.$notify({
        title: '成功',
        message: '删除成功',
        type: 'success',
        duration: 2000
      })
      this.list.splice(index, 1)
    },
    handleFetchPv(pv) {
      fetchPv(pv).then(response => {
        this.pvData = response.data.pvData
        this.dialogPvVisible = true
      })
    },
    handleDownload() {
      this.downloadLoading = true
      import('@/vendor/Export2Excel').then(excel => {
        const tHeader = ['序号', '期数', '中奖商品名称', '订单号', '订单状态', '收货价格', '收货地址', '导出时间:' + this.dateFormat('YYYY-mm-dd HH:MM', new Date())]
        const filterVal = ['id', 'codePeriod', 'goodsSName', 'orderNo', 'orderState', 'collectPrice', 'address']
        const data = this.formatJson(filterVal)
        excel.export_json_to_excel({
          header: tHeader,
          data,
          filename: 'table-list'
        })
        this.downloadLoading = false
      })
    },
    formatJson(filterVal) {
      return this.list.map(v => filterVal.map(j => {
        if (j === 'orderState') {
          return this.getValByKey(v[j], this.stateArr)
        } else {
          return v[j]
        }
      }))
    },
    getSortClass: function(key) {
      const sort = this.listQuery.sort
      return sort === `+${key}` ? 'ascending' : 'descending'
    }
  }
}
</script>
<style lang="scss" scoped>
  .submitAddress{
    padding-left: 10px;
    .el-tag{
      height: 35px;
      line-height: 35px;
      margin-left: 20px;
      vertical-align: top;
    }
  }
</style>
