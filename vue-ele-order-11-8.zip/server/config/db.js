//  数据库连接参数
const db = {
  // host: process.env.HOST,
  // port: process.env.PORT,
  // user: process.env.USER,
  // password: process.env.PASSWORD,
  // // socketPath: '/tmp/mysql.sock',
  // database: process.env.DATABASE,
  host: 'rm-bp1xy4ot6230i4fhbno.mysql.rds.aliyuncs.com',
  port: '3306',
  user: 'zhanlx2012',
  password: ' 998899aa',
  // socketPath: '/tmp/mysql.sock',
  database: 'order',
  dialect: 'mysql',
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
}
module.exports = db
