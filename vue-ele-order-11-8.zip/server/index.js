// node 后端服务器

const userApi = require('./api/userApi')
const orderApi = require('./api/orderApi')
const fs = require('fs')
const path = require('path')
const bodyParser = require('body-parser')
const express = require('express')
const app = express()
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))

// 后端api路由
app.use('/nodeApi/user', userApi)
app.use('/nodeApi/order', orderApi)

// 监听端口
app.listen(3000)
console.log('express 服务已启动，success listen at port:3000......')
console.log('dev', process)
