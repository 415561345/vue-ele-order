import request from '@/utils/request'

export function fetchList(query) {
  return request({
    url: '/vue-element-admin/article/list',
    method: 'get',
    params: query
  })
}
// 登录
export function accLogin(data) {
  return request({
    url: '/json/v5/users/login',
    method: 'post',
    data
  })
}
// 查询抽奖
export function queryPrize(data) {
  return request({
    url: '/api/member/v1/app/baseinfo',
    method: 'get',
    params: data
  })
}
// 查询中奖
export function queryZJiang(data) {
  return request({
    url: '/json/Android/Member',
    method: 'get',
    params: data
  })
}
// 查询订单详细信息
export function queryOrderDetail(data) {
  return request({
    url: '/api/lotorder/v1/app/orderdetail',
    method: 'get',
    params: data
  })
}

// 新增用户地址1
export function addUserAddress(data) {
  return request({
    url: '/json/Android/Member?action=addNewUserContact',
    method: 'get',
    params: data
  })
}
// 新增用户地址2
export function addUserAddress2(data) {
  return request({
    url: '/json/Android/Member?action=updateOrderShipInfoTran',
    method: 'get',
    params: data
  })
}
// 删除地址
export function delUserAddress(data) {
  return request({
    url: '/json/Android/Member?action=deleteUserContact',
    method: 'get',
    params: data
  })
}
// 地址插入到数据库
export function addAddressToDb(data) {
  return request({
    urlType: 'api2',
    url: '/nodeApi/order/addAddress',
    method: 'post',
    data
  })
}

export function fetchArticle(id) {
  return request({
    url: '/vue-element-admin/article/detail',
    method: 'get',
    params: { id }
  })
}

export function fetchPv(pv) {
  return request({
    url: '/vue-element-admin/article/pv',
    method: 'get',
    params: { pv }
  })
}

export function createArticle(data) {
  return request({
    url: '/vue-element-admin/article/create',
    method: 'post',
    data
  })
}

export function updateArticle(data) {
  return request({
    url: '/vue-element-admin/article/update',
    method: 'post',
    data
  })
}
